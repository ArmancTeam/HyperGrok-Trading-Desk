#!/usr/bin/env python3
"""Negative fixtures for scripts/check_manifests.py. Stdlib Python only; no network.

Each fixture copies the repository into a temporary directory, breaks the
distribution contract in exactly one way, and asserts the validator fails with
an error naming that file. A guard nobody has watched fail is not a guard.
"""
import json
import os
import shutil
import subprocess
import sys
import tempfile

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
VALIDATOR = os.path.join(ROOT, "scripts", "check_manifests.py")


def run(root):
    proc = subprocess.run(
        [sys.executable, VALIDATOR, root], capture_output=True, text=True, check=False
    )
    return proc.returncode, proc.stdout + proc.stderr


def edit(root, rel, mutate):
    path = os.path.join(root, rel)
    with open(path, encoding="utf-8") as fh:
        data = json.load(fh)
    mutate(data)
    with open(path, "w", encoding="utf-8") as fh:
        json.dump(data, fh, indent=2)


def version_mismatch(root):
    edit(root, ".grok-plugin/plugin.json", lambda d: d.update(version="9.9.9"))
    return ".grok-plugin/plugin.json", "version"


def nested_version_mismatch(root):
    edit(root, ".claude-plugin/marketplace.json",
         lambda d: d["plugins"][0].update(version="0.1.0"))
    return ".claude-plugin/marketplace.json", "plugins[0].version"


def missing_component_path(root):
    os.remove(os.path.join(root, "assets", "mascot-320.jpg"))
    return ".cursor-plugin/plugin.json", "logo"


def missing_component_directory(root):
    shutil.rmtree(os.path.join(root, "rules"))
    return ".cursor-plugin/plugin.json", "rules"


def path_escapes_repository(root):
    edit(root, ".cursor-plugin/plugin.json", lambda d: d.update(skills="../skills/"))
    return ".cursor-plugin/plugin.json", "outside the repository"


def invalid_json(root):
    path = os.path.join(root, ".claude-plugin", "marketplace.json")
    with open(path, "w", encoding="utf-8") as fh:
        fh.write('{"name": "hypergrok",\n')
    return ".claude-plugin/marketplace.json", "invalid JSON"


def inventory_drift(root):
    added = os.path.join(root, "skills", "desk-new-skill")
    os.makedirs(added)
    with open(os.path.join(added, "SKILL.md"), "w", encoding="utf-8") as fh:
        fh.write("---\nname: desk-new-skill\n---\n")
    shipped = sum(
        os.path.isfile(os.path.join(root, "skills", name, "SKILL.md"))
        for name in os.listdir(os.path.join(root, "skills"))
    )
    return "plugin.json", f"ships {shipped}"


def wrong_name(root):
    edit(root, ".grok-plugin/marketplace.json", lambda d: d["plugins"][0].update(name="hyper-grok"))
    return ".grok-plugin/marketplace.json", "plugins[0].name"


def replace(root, rel, old, new):
    path = os.path.join(root, rel)
    with open(path, encoding="utf-8") as fh:
        text = fh.read()
    assert old in text, f"{rel}: fixture anchor '{old}' not found"
    with open(path, "w", encoding="utf-8") as fh:
        fh.write(text.replace(old, new))


def documented_marketplace_typo(root):
    replace(root, "docs/hyperliquid-claude-code.md",
            "/plugin marketplace add galleonlabs/hypergrok-trading-desk",
            "/plugin marketplace add galleonlabs/hypergrok")
    return "docs/hyperliquid-claude-code.md", "/plugin marketplace add"


def documented_install_id_typo(root):
    replace(root, "docs/hyperliquid-claude-code.md", "/plugin install hypergrok@hypergrok",
            "/plugin install hypergrok@galleonlabs")
    return "docs/hyperliquid-claude-code.md", "/plugin install"


def marketplace_drops_documented_plugin(root):
    """Drift the other way: the docs still install a plugin the marketplace stopped declaring."""
    edit(root, ".claude-plugin/marketplace.json", lambda d: d.update(plugins=[]))
    return "docs/hyperliquid-claude-code.md", "/plugin install"


def documented_skills_sh_plugin_slug(root):
    """skills.sh indexes skill directories; the plugin id is not one of them."""
    replace(
        root,
        "README.md",
        "https://www.skills.sh/galleonlabs/hypergrok-trading-desk)",
        "https://www.skills.sh/galleonlabs/hypergrok-trading-desk/hypergrok)",
    )
    return "README.md", "is not a skill"


def documented_skills_add_typo(root):
    replace(
        root,
        "README.md",
        "skills add galleonlabs/hypergrok-trading-desk",
        "skills add galleonlabs/hypergrok",
    )
    return "README.md", "'skills add'"


def documented_pin_lags_the_release(root):
    """Bump the manifests, forget SETUP.md: the release installs the previous one."""
    edit(root, "plugin.json", lambda d: d.update(version="9.9.9"))
    for rel in (
        ".claude-plugin/plugin.json",
        ".cursor-plugin/plugin.json",
        ".grok-plugin/plugin.json",
    ):
        edit(root, rel, lambda d: d.update(version="9.9.9"))
    edit(root, ".claude-plugin/marketplace.json",
         lambda d: (d["metadata"].update(version="9.9.9"),
                    d["plugins"][0].update(version="9.9.9")))
    edit(root, ".grok-plugin/marketplace.json",
         lambda d: d["plugins"][0].update(version="9.9.9"))
    edit(root, "gemini-extension.json", lambda d: d.update(version="9.9.9"))
    for rel in (".grok-plugin/marketplace.json", ".agents/plugins/marketplace.json"):
        edit(root, rel, lambda d: d["plugins"][0]["source"].update(ref="v9.9.9"))
    return "SETUP.md", "expected v9.9.9"


def current_pin(root):
    """The tag `SETUP.md` pins today. Derived, so a release does not break these."""
    with open(os.path.join(root, "plugin.json"), encoding="utf-8") as fh:
        return "v" + json.load(fh)["version"]


def documented_pin_is_a_moving_branch(root):
    replace(root, "SETUP.md", f"--branch {current_pin(root)}", "--branch main")
    return "SETUP.md", "--branch main"


def documented_clone_is_unpinned(root):
    replace(root, "SETUP.md", f"--branch {current_pin(root)} ", "")
    return "SETUP.md", "is not pinned"


def stale_tag_in_runbook_prose(root):
    """The pin was bumped; the sentence explaining it still names the old tag."""
    replace(root, "SETUP.md", "That pin is a release tag", "`v0.9.0` is a release tag")
    return "SETUP.md", "names release tag v0.9.0"


def stale_tag_in_documented_url(root):
    """The manual fallback still links the previous release's instructions."""
    replace(root, "README.md", f"blob/{current_pin(root)}/SETUP.md", "blob/v0.9.0/SETUP.md")
    return "README.md", "names release tag v0.9.0"


def grok_marketplace_root_source(root):
    edit(root, ".grok-plugin/marketplace.json",
         lambda d: d["plugins"][0].update(source={"type": "local", "path": "./"}))
    return ".grok-plugin/marketplace.json", "source"


def grok_marketplace_stale_ref(root):
    edit(root, ".grok-plugin/marketplace.json",
         lambda d: d["plugins"][0].update(source={
             "source": "url", "url": "https://github.com/galleonlabs/hypergrok-trading-desk.git",
             "ref": "v0.9.0"}))
    return ".grok-plugin/marketplace.json", "ref"


def grok_marketplace_missing_ref(root):
    edit(root, ".grok-plugin/marketplace.json",
         lambda d: d["plugins"][0].update(source={
             "source": "url", "url": "https://github.com/galleonlabs/hypergrok-trading-desk.git"}))
    return ".grok-plugin/marketplace.json", "ref"


def grok_marketplace_wrong_url(root):
    edit(root, ".grok-plugin/marketplace.json",
         lambda d: d["plugins"][0].update(source={
             "source": "url", "url": "https://github.com/galleonlabs/other.git",
             "ref": current_pin(root)}))
    return ".grok-plugin/marketplace.json", "url"


def grok_documented_moving_ref(root):
    with open(os.path.join(root, "README.md"), "a", encoding="utf-8") as fh:
        fh.write("\ngrok plugin install galleonlabs/hypergrok-trading-desk@main --trust\n")
    return "README.md", "grok plugin install"


def grok_documented_missing_ref(root):
    with open(os.path.join(root, "docs", "FAQ.md"), "a", encoding="utf-8") as fh:
        fh.write("\ngrok plugin install galleonlabs/hypergrok-trading-desk --trust\n")
    return "docs/FAQ.md", "grok plugin install"


def gemini_version_mismatch(root):
    edit(root, "gemini-extension.json", lambda d: d.update(version="9.9.9"))
    return "gemini-extension.json", "version"


def gemini_missing_context_file(root):
    os.remove(os.path.join(root, "GEMINI.md"))
    return "gemini-extension.json", "contextFileName"


def gemini_context_drops_approval_rule(root):
    """The Gemini context file paraphrases the desk rule instead of repeating it."""
    replace(root, "GEMINI.md", "with the ticket id, after the ticket was shown",
            "after the ticket was shown")
    return "GEMINI.md", "rules/hypergrok-team.mdc"


def gemini_documented_wrong_repository(root):
    replace(root, "docs/hyperliquid-gemini-cli.md",
            "gemini extensions install https://github.com/galleonlabs/hypergrok-trading-desk",
            "gemini extensions install https://github.com/galleonlabs/hypergrok")
    return "docs/hyperliquid-gemini-cli.md", "gemini extensions install"


def gemini_documented_moving_ref(root):
    with open(os.path.join(root, "docs", "FAQ.md"), "a", encoding="utf-8") as fh:
        fh.write("\ngemini extensions install "
                 "https://github.com/galleonlabs/hypergrok-trading-desk --ref main\n")
    return "docs/FAQ.md", "--ref main"


def codex_marketplace_root_source(root):
    edit(root, ".agents/plugins/marketplace.json",
         lambda d: d["plugins"][0].update(source={"source": "local", "path": "./"}))
    return ".agents/plugins/marketplace.json", "source"


def codex_marketplace_stale_ref(root):
    edit(root, ".agents/plugins/marketplace.json",
         lambda d: d["plugins"][0]["source"].update(ref="v0.9.0"))
    return ".agents/plugins/marketplace.json", "ref"


def codex_marketplace_missing_policy(root):
    edit(root, ".agents/plugins/marketplace.json", lambda d: d["plugins"][0].pop("policy"))
    return ".agents/plugins/marketplace.json", "policy"


def codex_marketplace_missing_category(root):
    edit(root, ".agents/plugins/marketplace.json", lambda d: d["plugins"][0].pop("category"))
    return ".agents/plugins/marketplace.json", "category"


def codex_documented_marketplace_typo(root):
    replace(root, "docs/hyperliquid-codex.md",
            "codex plugin marketplace add galleonlabs/hypergrok-trading-desk",
            "codex plugin marketplace add galleonlabs/hypergrok")
    return "docs/hyperliquid-codex.md", "codex plugin marketplace add"


def codex_documented_install_id_typo(root):
    replace(root, "docs/hyperliquid-codex.md", "codex plugin add hypergrok@hypergrok",
            "codex plugin add hypergrok@galleonlabs")
    return "docs/hyperliquid-codex.md", "codex plugin add"


def codex_marketplace_renamed(root):
    """The Codex index changes its marketplace name; the documented install id goes stale."""
    edit(root, ".agents/plugins/marketplace.json", lambda d: d.update(name="galleonlabs"))
    return "docs/hyperliquid-codex.md", "codex plugin add"


def codex_documented_moving_ref(root):
    with open(os.path.join(root, "docs", "FAQ.md"), "a", encoding="utf-8") as fh:
        fh.write("\ncodex plugin marketplace add galleonlabs/hypergrok-trading-desk --ref main\n")
    return "docs/FAQ.md", "--ref main"


FIXTURES = [
    gemini_version_mismatch,
    gemini_missing_context_file,
    gemini_context_drops_approval_rule,
    gemini_documented_wrong_repository,
    gemini_documented_moving_ref,
    codex_marketplace_root_source,
    codex_marketplace_stale_ref,
    codex_marketplace_missing_policy,
    codex_marketplace_missing_category,
    codex_documented_marketplace_typo,
    codex_documented_install_id_typo,
    codex_marketplace_renamed,
    codex_documented_moving_ref,
    grok_marketplace_root_source,
    grok_marketplace_stale_ref,
    grok_marketplace_missing_ref,
    grok_marketplace_wrong_url,
    grok_documented_moving_ref,
    grok_documented_missing_ref,
    version_mismatch,
    nested_version_mismatch,
    missing_component_path,
    missing_component_directory,
    path_escapes_repository,
    invalid_json,
    inventory_drift,
    wrong_name,
    documented_marketplace_typo,
    documented_install_id_typo,
    marketplace_drops_documented_plugin,
    documented_skills_sh_plugin_slug,
    documented_skills_add_typo,
    documented_pin_lags_the_release,
    documented_pin_is_a_moving_branch,
    documented_clone_is_unpinned,
    stale_tag_in_runbook_prose,
    stale_tag_in_documented_url,
]


def main():
    failures = []
    with tempfile.TemporaryDirectory() as tmp:
        baseline = os.path.join(tmp, "baseline")
        shutil.copytree(ROOT, baseline, ignore=shutil.ignore_patterns(".git", "__pycache__"))
        code, output = run(baseline)
        if code != 0:
            failures.append(f"baseline copy should pass but failed:\n{output}")

        for fixture in FIXTURES:
            case = os.path.join(tmp, fixture.__name__)
            shutil.copytree(baseline, case)
            rel, needle = fixture(case)
            code, output = run(case)
            if code == 0:
                failures.append(f"{fixture.__name__}: validator passed but should have failed")
            elif rel not in output or needle not in output:
                failures.append(
                    f"{fixture.__name__}: expected an error naming '{rel}' and '{needle}', got:\n{output}"
                )

    if failures:
        print("\n".join(failures))
        print(f"{len(failures)} problem(s)")
        return 1
    print(f"ok: {len(FIXTURES)} manifest fixtures fail the check as expected")
    return 0


if __name__ == "__main__":
    sys.exit(main())
