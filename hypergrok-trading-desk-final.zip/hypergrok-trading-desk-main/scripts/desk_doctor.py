#!/usr/bin/env python3
"""Check a HyperGrok install without reading keys or changing desk state."""

from __future__ import annotations

import hashlib
import json
import os
import re
import sys
import urllib.error
import urllib.request
from dataclasses import asdict, dataclass

from cli_contract import ReadOnlyParser, add_network_arguments, describe, emit_error, network_settings

SEMVER_RE = re.compile(r"^\d+\.\d+\.\d+$")
# What the checkout says it ships, read from the two lists it already publishes
# and `scripts/check.sh` already keeps honest: the skills index links every skill,
# and the runbook the user follows names every profile it tells them to create.
SKILL_INDEX = ("skills/README.md", re.compile(r"\[([a-z0-9-]+)\]\(\1/SKILL\.md\)"))
# The reviewed bytes of every skill the release ships, already published by the
# checkout and already kept honest by `scripts/check_grok_template.py`.
TEMPLATE_MANIFEST = "template/grok-bot.json"
AGENT_INDEX = ("SETUP.md", re.compile(r"`agents/([a-z0-9-]+)\.md`"))
REQUIRED_DESK_DIRS = (
    "proposals",
    "briefs",
    "research",
    "strategies",
    "data",
    "journal/incidents",
    "watch",
)


@dataclass(frozen=True)
class Check:
    status: str
    name: str
    detail: str


def result(condition: bool, name: str, pass_detail: str, fail_detail: str) -> Check:
    return Check("PASS" if condition else "FAIL", name, pass_detail if condition else fail_detail)


def present_skills(root: str) -> set[str]:
    directory = os.path.join(root, "skills")
    if not os.path.isdir(directory):
        return set()
    return {name for name in os.listdir(directory) if os.path.isfile(os.path.join(directory, name, "SKILL.md"))}


def present_agents(root: str) -> set[str]:
    directory = os.path.join(root, "agents")
    if not os.path.isdir(directory):
        return set()
    return {name[:-3] for name in os.listdir(directory) if name.endswith(".md") and os.path.isfile(os.path.join(directory, name))}


def inventory(root: str, name: str, index: tuple[str, re.Pattern], present: set[str]) -> Check:
    """Check the install component by component, against the list it publishes.

    Counting was the wrong question twice over. A count has to be bumped at every
    release - the defect the version check no longer has - and it passes a tree
    holding the right number of the wrong things, so an unpacked archive that
    dropped one skill and left a stray directory behind read as a healthy desk.
    Naming what is missing is also what the user needs: they can restore one path,
    rather than diff seventeen directories against the runbook.

    A directory the index does not list only warns. Missing is caught by name now,
    so an extra can no longer mask one, and a user's own skill is not a broken desk.
    """
    source, pattern = index
    try:
        with open(os.path.join(root, source), encoding="utf-8") as handle:
            declared = set(pattern.findall(handle.read()))
    except OSError as exc:
        return Check("FAIL", name, f"cannot read {source}: {exc}")
    if not declared:
        return Check("FAIL", name, f"{source} lists no {name}; this checkout cannot say what it ships")
    missing = sorted(declared - present)
    if missing:
        return Check("FAIL", name, f"{len(declared) - len(missing)} of {len(declared)} present; missing {', '.join(missing)}")
    extra = sorted(present - declared)
    if extra:
        return Check("WARN", name, f"all {len(declared)} present; {source} does not list {', '.join(extra)}")
    return Check("PASS", name, f"all {len(declared)} present")


def skill_bytes(root: str) -> Check:
    """Compare each shipped skill body with the bytes the release reviewed.

    Naming what is missing still passes a desk whose skills are all present and
    one of them is not what was reviewed. `SETUP.md` section 1 judges the clone
    by `scripts/check.sh`, which catches that through this same manifest, but
    section 9 and `hypergrok-bootstrap` run the doctor alone, and `README.md`
    offers it as the desk's standing health tool. So a skill body edited or
    truncated after the install gate - a Risk Manager whose sizing rules no
    longer say what the desk agreed - read as a healthy desk. The manifest is
    already in the checkout and already the release's own statement of those
    bytes; the doctor now reads it and names every path that no longer matches.
    """
    path = os.path.join(root, TEMPLATE_MANIFEST)
    try:
        with open(path, encoding="utf-8") as handle:
            entries = json.load(handle)["skills"]
        claimed = [(str(entry["path"]), str(entry["sha256"])) for entry in entries]
    except (OSError, json.JSONDecodeError, KeyError, TypeError) as exc:
        return Check("FAIL", "skill bytes", f"cannot read {TEMPLATE_MANIFEST}: {exc}")
    if not claimed:
        return Check("FAIL", "skill bytes", f"{TEMPLATE_MANIFEST} claims no skill bytes; this checkout cannot say what it ships")

    changed, unreadable = [], []
    for relative, expected in claimed:
        digest = hashlib.sha256()
        try:
            with open(os.path.join(root, relative), "rb") as handle:
                for chunk in iter(lambda: handle.read(65536), b""):
                    digest.update(chunk)
        except OSError:
            unreadable.append(relative)
            continue
        if digest.hexdigest() != expected:
            changed.append(relative)
    if not changed and not unreadable:
        return Check("PASS", "skill bytes", f"all {len(claimed)} match {TEMPLATE_MANIFEST}")
    named = []
    if changed:
        named.append(f"changed: {', '.join(sorted(changed))}")
    if unreadable:
        named.append(f"unreadable: {', '.join(sorted(unreadable))}")
    matched = len(claimed) - len(changed) - len(unreadable)
    return Check("FAIL", "skill bytes", f"{matched} of {len(claimed)} match the reviewed bytes; {'; '.join(named)}")


def check_repository(root: str) -> list[Check]:
    checks = []
    # `plugin.json` is the release this checkout claims to be. Every other
    # release fact is read against it rather than against a constant here: a
    # constant would have to be bumped at every release, and a doctor that
    # lags the tag it ships in tells a correctly installed desk it is broken.
    version = None
    try:
        with open(os.path.join(root, "plugin.json"), encoding="utf-8") as handle:
            manifest = json.load(handle)
        if not isinstance(manifest, dict):
            raise ValueError("plugin.json must be an object")
        version = manifest.get("version")
        valid = isinstance(version, str) and bool(SEMVER_RE.match(version))
        checks.append(result(valid, "release", f"manifest version {version}", f"plugin.json version {version!r} is not a release version"))
    except (OSError, ValueError) as exc:
        checks.append(Check("FAIL", "release", f"cannot read plugin.json: {exc}"))

    checks.append(inventory(root, "skills", SKILL_INDEX, present_skills(root)))
    checks.append(inventory(root, "agents", AGENT_INDEX, present_agents(root)))
    checks.append(skill_bytes(root))

    setup_path = os.path.join(root, "SETUP.md")
    expected_tag = f"v{version}" if version else None
    try:
        with open(setup_path, encoding="utf-8") as handle:
            setup = handle.read()
        if expected_tag is None:
            checks.append(Check("FAIL", "setup pin", "no manifest version to check the pin against"))
        else:
            pinned = f"--branch {expected_tag}" in setup
            checks.append(result(pinned, "setup pin", expected_tag, f"SETUP.md does not pin {expected_tag}; this checkout is a half-updated release"))
    except OSError as exc:
        checks.append(Check("FAIL", "setup pin", f"cannot read SETUP.md: {exc}"))

    required = ("scripts/check.sh", "scripts/desk_doctor.py", "scripts/opening_bell.py", "skills/hypergrok-bootstrap/SKILL.md")
    missing = [path for path in required if not os.path.isfile(os.path.join(root, path))]
    checks.append(result(not missing, "release files", "bootstrap, doctor and demo present", f"missing: {', '.join(missing)}"))
    return checks


def check_workspace(root: str) -> list[Check]:
    checks = []
    missing = [path for path in REQUIRED_DESK_DIRS if not os.path.isdir(os.path.join(root, path))]
    checks.append(result(not missing, "desk folders", "working folders present", f"missing: {', '.join(missing)}"))

    desk_path = os.path.join(root, "desk.md")
    if not os.path.isfile(desk_path):
        checks.append(Check("WARN", "desk record", f"{desk_path} is not written yet"))
    else:
        with open(desk_path, encoding="utf-8") as handle:
            text = handle.read()
        safe = not re.search(r"private.?key|secret\s*[:=]\s*\S+", text, re.IGNORECASE)
        checks.append(result(safe, "desk record", "present; no key-like field detected", "contains a key-like field; remove secrets from disk"))
        if "risk limits: not yet written" in text or not os.path.isfile(os.path.join(root, "risk-limits.md")):
            checks.append(Check("WARN", "risk limits", "not written; desk remains research-only"))
        else:
            checks.append(Check("PASS", "risk limits", "risk-limits.md present"))
    return checks


def check_public_api(base_url: str, timeout: float) -> Check:
    request = urllib.request.Request(
        f"{base_url.rstrip('/')}/info",
        data=b'{"type":"allMids"}',
        headers={"Content-Type": "application/json", "User-Agent": "hypergrok-desk-doctor/1.0"},
        method="POST",
    )
    try:
        with urllib.request.urlopen(request, timeout=timeout) as response:
            payload = json.load(response)
        if not isinstance(payload, dict) or not payload.get("ETH"):
            return Check("FAIL", "public API", "allMids response did not contain ETH")
        network = "mainnet" if base_url == "https://api.hyperliquid.xyz" else "testnet" if base_url == "https://api.hyperliquid-testnet.xyz" else "custom"
        return Check("PASS", "public API", f"{network} /info allMids answered without a key")
    except (OSError, urllib.error.URLError, json.JSONDecodeError) as exc:
        return Check("FAIL", "public API", f"unavailable: {exc}")


def render(checks: list[Check]) -> str:
    width = max(len(check.name) for check in checks)
    lines = ["HYPERGROK DESK DOCTOR", "READ ONLY · no key access · no writes", ""]
    lines.extend(f"{check.status:<4}  {check.name:<{width}}  {check.detail}" for check in checks)
    failed = sum(check.status == "FAIL" for check in checks)
    warned = sum(check.status == "WARN" for check in checks)
    lines.extend(["", f"Result: {len(checks) - failed - warned} passed, {warned} warnings, {failed} failed."])
    return "\n".join(lines)


def main(argv=None) -> int:
    argv = list(sys.argv[1:] if argv is None else argv)
    parser = ReadOnlyParser(description=__doc__, machine_readable="--json" in argv or "--schema" in argv)
    parser.add_argument("--repo-root", default=os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
    parser.add_argument("--desk-root", help="also validate a prepared trading-desk directory")
    add_network_arguments(parser)
    parser.add_argument("--offline", action="store_true", help="skip the public connectivity check")
    parser.add_argument("--json", action="store_true")
    args = parser.parse_args(argv)
    if args.schema:
        print(json.dumps(describe("desk_doctor", {"schema_version": 1, "mode": "read-only",
            "network": "mainnet | testnet | custom", "checks": [{"status": "PASS | WARN | FAIL | SKIP", "name": "string", "detail": "string"}],
            "safety": "No key access. No exchange writes. An offline SKIP does not prove connectivity; warnings do not establish trading readiness."
        }), indent=2))
        return 0
    base_url, network = network_settings(args, parser)

    try:
        checks = check_repository(os.path.abspath(args.repo_root))
        if args.desk_root:
            checks.extend(check_workspace(os.path.abspath(args.desk_root)))
        checks.append(Check("SKIP", "public API", "offline mode") if args.offline else check_public_api(base_url, args.timeout))
    except (OSError, ValueError, KeyError, TypeError) as exc:
        if args.json:
            emit_error("source_unavailable", str(exc))
        else:
            print(f"Desk doctor unavailable: {exc}", file=sys.stderr)
        return 1
    if args.json:
        print(json.dumps({"schema_version": 1, "mode": "read-only", "network": network,
                          "checks": [asdict(check) for check in checks]}, indent=2))
    else:
        print(render(checks))
    return 1 if any(check.status == "FAIL" for check in checks) else 0


if __name__ == "__main__":
    sys.exit(main())
