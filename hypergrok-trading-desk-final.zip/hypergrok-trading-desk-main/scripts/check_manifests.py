#!/usr/bin/env python3
"""Validates the plugin distribution manifests. Stdlib Python only; no network.

Every marketplace and plugin manifest in this repository describes the same
distributable: one plugin named `hypergrok` at one version, pointing at the
skills, agents and rules checked in here, and the install commands the docs
tell a user to type must name that same distributable. This script fails the
build when a manifest stops matching what the repository actually ships.

Usage: python3 scripts/check_manifests.py [repo-root]
"""
import json
import os
import re
import sys

CANONICAL_NAME = "hypergrok"
REPOSITORY = "https://github.com/galleonlabs/hypergrok-trading-desk"

MANIFESTS = [
    "plugin.json",
    ".claude-plugin/plugin.json",
    ".claude-plugin/marketplace.json",
    ".cursor-plugin/plugin.json",
    ".grok-plugin/plugin.json",
    ".grok-plugin/marketplace.json",
    "gemini-extension.json",
    ".agents/plugins/marketplace.json",
]

# Manifest keys whose value is a path into this repository.
PATH_KEYS = ("source", "logo", "skills", "agents", "rules", "hooks", "contextFileName")

# The marketplace manifest Claude Code resolves `/plugin marketplace add` against.
MARKETPLACE_MANIFEST = ".claude-plugin/marketplace.json"
GROK_MARKETPLACE_MANIFEST = ".grok-plugin/marketplace.json"
# Codex reads a repository marketplace from `.agents/plugins/marketplace.json`
# in preference to the Claude-compatible one.
CODEX_MARKETPLACE_MANIFEST = ".agents/plugins/marketplace.json"
# Marketplaces whose plugin entry is this repository at its release tag.
PINNED_SOURCE_MANIFESTS = (GROK_MARKETPLACE_MANIFEST, CODEX_MARKETPLACE_MANIFEST)
CODEX_INSTALL_POLICIES = ("AVAILABLE", "INSTALLED_BY_DEFAULT", "NOT_AVAILABLE")
CODEX_AUTH_POLICIES = ("ON_INSTALL", "ON_USE")
GEMINI_MANIFEST = "gemini-extension.json"
# Gemini CLI loads the context file on every session, so it must carry the
# desk rule's approval paragraph word for word rather than a paraphrase.
DESK_RULE = "rules/hypergrok-team.mdc"
APPROVAL_PARAGRAPH_START = "Analysis is not approval."
GROK_INSTALL_RE = re.compile(r"\bgrok plugin install\s+([^\s`]+)")
MARKETPLACE_ADD_RE = re.compile(r"/plugin marketplace add\s+([^\s`]+)")
PLUGIN_INSTALL_RE = re.compile(r"/plugin install\s+([^\s`]+)")
GEMINI_INSTALL_RE = re.compile(r"\bgemini extensions install\s+([^\s`]+)([^\n`]*)")
CODEX_MARKETPLACE_ADD_RE = re.compile(r"\bcodex plugin marketplace add\s+([^\s`]+)([^\n`]*)")
CODEX_PLUGIN_ADD_RE = re.compile(r"\bcodex plugin add\s+([^\s`]+)")
REF_OPTION_RE = re.compile(r"--ref(?:=|\s+)([^\s`]+)")
# skills.sh indexes skill directories, not the plugin id. A trailing /hypergrok
# is therefore a listing that does not exist.
SKILLS_SH_RE = re.compile(
    r"https://(?:www\.)?skills\.sh/([A-Za-z0-9_.-]+/[A-Za-z0-9_.-]+(?:/[A-Za-z0-9_.-]+)?)"
)
SKILLS_ADD_RE = re.compile(
    r"\bskills add\s+([A-Za-z0-9_.-]+/[A-Za-z0-9_.-]+(?:/[A-Za-z0-9_.-]+)?)"
)
# `SETUP.md` section 1 clones a pinned tag, so a `git clone` of this repository
# in the docs must name the tag of the version the manifests declare.
CLONE_RE = re.compile(r"git clone[^\n]*")
CLONE_BRANCH_RE = re.compile(r"--branch(?:=|\s+)([^\s`]+)")
# Any other way the docs name a release tag: a `blob`/`tree`/`raw` URL into this
# repository, or prose that quotes the tag the reader is told to install.
VERSION_TAG_RE = re.compile(r"\bv\d+\.\d+\.\d+\b")
# `CHANGELOG.md` records every past release and `CONTRIBUTING.md` documents the
# release procedure against historical tags; both name old versions by design.
RELEASE_HISTORY_DOCS = ("CHANGELOG.md", "CONTRIBUTING.md")

NUMBER_WORDS = {
    "one": 1, "two": 2, "three": 3, "four": 4, "five": 5, "six": 6,
    "seven": 7, "eight": 8, "nine": 9, "ten": 10, "eleven": 11,
    "twelve": 12, "thirteen": 13, "fourteen": 14, "fifteen": 15,
    "sixteen": 16, "seventeen": 17, "eighteen": 18, "nineteen": 19,
    "twenty": 20,
}
COUNT_RE = re.compile(r"\b([A-Za-z]+|\d+)[ -](?:specialist |shared )?(roles?|skills?)\b")


def load(root, rel, errors):
    path = os.path.join(root, rel)
    if not os.path.exists(path):
        errors.append(f"{rel}: manifest is missing")
        return None
    try:
        with open(path, encoding="utf-8") as fh:
            return json.load(fh)
    except json.JSONDecodeError as exc:
        errors.append(f"{rel}: invalid JSON at line {exc.lineno} column {exc.colno}: {exc.msg}")
    except UnicodeDecodeError as exc:
        errors.append(f"{rel}: not valid UTF-8: {exc}")
    return None


def entries(data):
    """The manifest object itself plus any nested marketplace plugin entries."""
    if not isinstance(data, dict):
        return []
    found = [("", data)]
    for i, plugin in enumerate(data.get("plugins") or []):
        if isinstance(plugin, dict):
            found.append((f"plugins[{i}].", plugin))
    return found


def check_paths(root, rel, prefix, entry, errors):
    for key in PATH_KEYS:
        if key not in entry:
            continue
        value = entry[key]
        if rel in PINNED_SOURCE_MANIFESTS and key == "source":
            continue  # checked as a pinned remote source by check_pinned_source
        if isinstance(value, dict):
            if value.get("type") not in (None, "local"):
                continue  # a remote source is not this repository's tree
            value = value.get("path")
        # Gemini CLI accepts one context file name or a list of them.
        for item in value if key == "contextFileName" and isinstance(value, list) else [value]:
            check_path(root, rel, prefix, key, item, errors)


def check_path(root, rel, prefix, key, value, errors):
    if not isinstance(value, str) or not value:
        errors.append(f"{rel}: {prefix}{key} is not a path")
        return
    if value.startswith(("http://", "https://")):
        errors.append(f"{rel}: {prefix}{key} must be a repository path, not a URL")
        return
    resolved = os.path.normpath(os.path.join(root, value))
    inside = os.path.normpath(root)
    if os.path.relpath(resolved, inside).startswith(".."):
        errors.append(f"{rel}: {prefix}{key} '{value}' resolves outside the repository")
        return
    if not os.path.exists(resolved):
        errors.append(f"{rel}: {prefix}{key} '{value}' does not exist")


def check_pinned_source(rel, prefix, entry, version, errors):
    """Install this repository at its release tag, not a moving marketplace root.

    Grok rejects a marketplace-root path. Codex would accept one, but it would
    then install whatever ref the marketplace was added at, usually `main`.
    """
    source = entry.get("source")
    if not isinstance(source, dict) or source.get("source") != "url":
        errors.append(f"{rel}: {prefix}source must use the pinned remote URL form")
        return
    if source.get("url") != REPOSITORY + ".git":
        errors.append(f"{rel}: {prefix}source.url must be '{REPOSITORY}.git'")
    if version is not None and source.get("ref") != f"v{version}":
        errors.append(f"{rel}: {prefix}source.ref must pin v{version}")


def check_codex_entry(rel, prefix, entry, errors):
    """Codex's marketplace format requires an install policy and a category per entry."""
    policy = entry.get("policy")
    if not isinstance(policy, dict):
        errors.append(f"{rel}: {prefix}policy is required")
        return
    if policy.get("installation") not in CODEX_INSTALL_POLICIES:
        errors.append(
            f"{rel}: {prefix}policy.installation must be one of {list(CODEX_INSTALL_POLICIES)}"
        )
    if policy.get("authentication") not in CODEX_AUTH_POLICIES:
        errors.append(
            f"{rel}: {prefix}policy.authentication must be one of {list(CODEX_AUTH_POLICIES)}"
        )
    if not isinstance(entry.get("category"), str) or not entry["category"]:
        errors.append(f"{rel}: {prefix}category is required")


def check_gemini_context(root, manifest, errors):
    """Each Gemini context file repeats the desk rule's approval paragraph verbatim."""
    if not isinstance(manifest, dict):
        return
    try:
        with open(os.path.join(root, DESK_RULE), encoding="utf-8") as fh:
            rule = fh.read()
    except OSError as exc:
        errors.append(f"{DESK_RULE}: cannot read the desk rule: {exc}")
        return
    paragraph = next(
        (p.strip() for p in rule.split("\n\n") if p.startswith(APPROVAL_PARAGRAPH_START)),
        None,
    )
    if paragraph is None:
        errors.append(f"{DESK_RULE}: no paragraph starts '{APPROVAL_PARAGRAPH_START}'")
        return
    names = manifest.get("contextFileName", "GEMINI.md")
    for name in names if isinstance(names, list) else [names]:
        path = os.path.join(root, name) if isinstance(name, str) else None
        if path is None or not os.path.isfile(path):
            continue  # reported by the path check
        with open(path, encoding="utf-8") as fh:
            if paragraph not in fh.read():
                errors.append(
                    f"{name}: must repeat the approval paragraph of {DESK_RULE} verbatim"
                )


def declared_counts(value, found):
    """Collect counts a manifest claims in prose, e.g. 'sixteen skills'."""
    if isinstance(value, dict):
        for item in value.values():
            declared_counts(item, found)
    elif isinstance(value, list):
        for item in value:
            declared_counts(item, found)
    elif isinstance(value, str):
        for token, noun in COUNT_RE.findall(value.lower()):
            count = int(token) if token.isdigit() else NUMBER_WORDS.get(token)
            if count is not None:
                found.append((count, "skills" if noun.startswith("skill") else "roles"))


def markdown_files(root):
    found = []
    for dirpath, dirnames, filenames in os.walk(root):
        dirnames[:] = [d for d in dirnames if d not in (".git", "__pycache__", "node_modules")]
        for name in sorted(filenames):
            if name.endswith(".md"):
                found.append(os.path.relpath(os.path.join(dirpath, name), root))
    return sorted(found)


def check_skills_pack_target(rel, kind, target, shorthand, skill_names, errors):
    """A skills.sh path or `skills add` argument must name this pack or a skill it ships.

    The plugin id is not a skill. skills.sh renders `/hypergrok` as a missing
    skill even though the pack page for this repository is live.
    """
    parts = target.split("/")
    if len(parts) not in (2, 3):
        errors.append(f"{rel}: {kind} '{target}' should name '{shorthand}'")
        return
    repo = f"{parts[0]}/{parts[1]}"
    if repo != shorthand:
        errors.append(f"{rel}: {kind} '{target}' should name '{shorthand}'")
        return
    if len(parts) == 3 and parts[2] not in skill_names:
        errors.append(
            f"{rel}: {kind} '{target}' names '{parts[2]}', which is not a skill "
            "this repository ships"
        )


def check_documented_pin(root, version, errors):
    """An instruction file may only name the release it ships in.

    `CONTRIBUTING.md`: the tag must contain a `SETUP.md` that pins to that same
    tag. Bumping the manifests and forgetting the pin ships a release whose
    install instructions build the *previous* one, and nothing about that fails
    loudly - the user reads one set of instructions and installs another. The
    manifest version is the release being cut, so `v<version>` is the only tag
    a clone command in these docs may name.

    The clone command is not the only place a tag is written down. `SETUP.md`
    explains the pin in prose beneath it and `README.md` links `blob/<tag>`
    instructions for the manual fallback; both have drifted a release behind a
    correct `--branch` pin, which tells the reader two different releases are
    the reviewed one. So every `v<x.y.z>` in these files is held to the same
    rule, and only the release history is allowed to name older tags.
    """
    if version is None:
        return
    expected = f"v{version}"
    for rel in markdown_files(root):
        if rel in RELEASE_HISTORY_DOCS:
            continue  # historical records, pinned to the releases they describe
        with open(os.path.join(root, rel), encoding="utf-8") as fh:
            text = fh.read()
        for tag in sorted(set(VERSION_TAG_RE.findall(text))):
            if tag != expected:
                errors.append(
                    f"{rel}: names release tag {tag}, but the manifests declare "
                    f"{expected}; an instruction file may only name the release "
                    "it ships in"
                )
        for target in GROK_INSTALL_RE.findall(text):
            if target == CANONICAL_NAME:
                continue  # marketplace install uses the validated index ref
            expected_target = REPOSITORY.removeprefix("https://github.com/") + "@" + expected
            if target != expected_target:
                errors.append(
                    f"{rel}: 'grok plugin install {target}' must use '{expected_target}'"
                )
        for command in CLONE_RE.findall(text):
            if REPOSITORY not in command:
                continue  # cloning something else, or prose about `git clone`
            found = CLONE_BRANCH_RE.search(command)
            if not found:
                errors.append(
                    f"{rel}: 'git clone' of this repository is not pinned; "
                    f"it needs --branch {expected}"
                )
            elif found.group(1) != expected:
                errors.append(
                    f"{rel}: 'git clone --branch {found.group(1)}' does not pin "
                    f"the version the manifests declare (expected {expected})"
                )


def check_documented_install(root, marketplace, skill_names, errors):
    """Install commands in the docs must name ids this repository actually declares.

    A wrong marketplace or plugin id is the one defect a reader cannot work
    around: the command simply fails for them. The same is true of a skills.sh
    listing or `skills add` argument that names a slug the pack does not ship.
    """
    if not isinstance(marketplace, dict):
        return
    shorthand = REPOSITORY.removeprefix("https://github.com/")
    market_name = marketplace.get("name")
    install_ids = {
        f"{p.get('name')}@{market_name}"
        for p in (marketplace.get("plugins") or [])
        if isinstance(p, dict)
    }
    for rel in markdown_files(root):
        with open(os.path.join(root, rel), encoding="utf-8") as fh:
            text = fh.read()
        for arg in MARKETPLACE_ADD_RE.findall(text):
            if arg != shorthand:
                errors.append(
                    f"{rel}: '/plugin marketplace add {arg}' should add '{shorthand}'"
                )
        for arg in PLUGIN_INSTALL_RE.findall(text):
            if arg not in install_ids:
                errors.append(
                    f"{rel}: '/plugin install {arg}' is not declared by "
                    f"{MARKETPLACE_MANIFEST} (expected one of {sorted(install_ids)})"
                )
        for arg in SKILLS_SH_RE.findall(text):
            check_skills_pack_target(
                rel, "skills.sh listing", arg, shorthand, skill_names, errors
            )
        for arg in SKILLS_ADD_RE.findall(text):
            check_skills_pack_target(
                rel, "'skills add'", arg, shorthand, skill_names, errors
            )


def check_documented_ref(rel, command, options, expected, errors):
    found = REF_OPTION_RE.search(options)
    if found and found.group(1) != expected:
        errors.append(
            f"{rel}: '{command} --ref {found.group(1)}' must pin {expected} or omit --ref"
        )


def check_documented_cli_installs(root, codex_marketplace, version, errors):
    """Gemini CLI and Codex install commands must name this repository and its ids.

    Gemini CLI installs the latest GitHub release when no ref is given, and the
    Codex marketplace index pins the release itself, so neither command needs a
    ref. A ref that is given must be the release the manifests declare.
    """
    shorthand = REPOSITORY.removeprefix("https://github.com/")
    expected = f"v{version}" if version is not None else None
    market = codex_marketplace if isinstance(codex_marketplace, dict) else {}
    install_ids = {
        f"{p.get('name')}@{market.get('name')}"
        for p in (market.get("plugins") or [])
        if isinstance(p, dict)
    }
    for rel in markdown_files(root):
        with open(os.path.join(root, rel), encoding="utf-8") as fh:
            text = fh.read()
        pin_checked = expected is not None and rel not in RELEASE_HISTORY_DOCS
        for source, options in GEMINI_INSTALL_RE.findall(text):
            if source not in (REPOSITORY, REPOSITORY + ".git"):
                errors.append(
                    f"{rel}: 'gemini extensions install {source}' should install '{REPOSITORY}'"
                )
            if pin_checked:
                check_documented_ref(
                    rel, f"gemini extensions install {source}", options, expected, errors
                )
        for source, options in CODEX_MARKETPLACE_ADD_RE.findall(text):
            if source.startswith(shorthand + "@"):
                # `owner/repo@ref` is Codex shorthand for `owner/repo --ref ref`.
                source, ref = source.split("@", 1)
                options = f" --ref {ref}{options}"
            if source != shorthand:
                errors.append(
                    f"{rel}: 'codex plugin marketplace add {source}' should add '{shorthand}'"
                )
            if pin_checked:
                check_documented_ref(
                    rel, f"codex plugin marketplace add {source}", options, expected, errors
                )
        for arg in CODEX_PLUGIN_ADD_RE.findall(text):
            if arg not in install_ids:
                errors.append(
                    f"{rel}: 'codex plugin add {arg}' is not declared by "
                    f"{CODEX_MARKETPLACE_MANIFEST} (expected one of {sorted(install_ids)})"
                )


def main(root):
    errors = []
    skills = sorted(
        d for d in os.listdir(os.path.join(root, "skills"))
        if os.path.exists(os.path.join(root, "skills", d, "SKILL.md"))
    )
    agents = sorted(f for f in os.listdir(os.path.join(root, "agents")) if f.endswith(".md"))
    inventory = {"skills": len(skills), "roles": len(agents)}
    if not skills:
        errors.append("skills/: no skill directories with a SKILL.md")
    if not agents:
        errors.append("agents/: no agent files")

    root_manifest = load(root, MANIFESTS[0], errors)
    version = (root_manifest or {}).get("version")
    if not isinstance(version, str) or not re.fullmatch(r"\d+\.\d+\.\d+", version):
        errors.append(f"{MANIFESTS[0]}: version '{version}' is not a semantic version")
        version = None

    marketplace = codex_marketplace = gemini = None
    for rel in MANIFESTS:
        data = root_manifest if rel == MANIFESTS[0] else load(root, rel, errors)
        if data is None:
            continue
        if rel == MARKETPLACE_MANIFEST:
            marketplace = data
        elif rel == CODEX_MARKETPLACE_MANIFEST:
            codex_marketplace = data
        elif rel == GEMINI_MANIFEST:
            gemini = data
        for prefix, entry in entries(data):
            name = entry.get("name")
            if name != CANONICAL_NAME:
                errors.append(f"{rel}: {prefix}name '{name}' should be '{CANONICAL_NAME}'")
            declared = entry.get("version", (entry.get("metadata") or {}).get("version"))
            if declared is not None and version is not None and declared != version:
                errors.append(
                    f"{rel}: {prefix}version '{declared}' does not match "
                    f"{MANIFESTS[0]} version '{version}'"
                )
            for key in ("repository", "homepage"):
                if key in entry and entry[key] != REPOSITORY:
                    errors.append(f"{rel}: {prefix}{key} '{entry[key]}' should be '{REPOSITORY}'")
            check_paths(root, rel, prefix, entry, errors)
            if rel in PINNED_SOURCE_MANIFESTS and prefix:
                check_pinned_source(rel, prefix, entry, version, errors)
            if rel == CODEX_MARKETPLACE_MANIFEST and prefix:
                check_codex_entry(rel, prefix, entry, errors)

        counts = []
        declared_counts(data, counts)
        for count, noun in counts:
            if count != inventory[noun]:
                errors.append(
                    f"{rel}: claims {count} {noun} but the repository ships {inventory[noun]}"
                )

    check_documented_install(root, marketplace, set(skills), errors)
    check_documented_cli_installs(root, codex_marketplace, version, errors)
    check_documented_pin(root, version, errors)
    check_gemini_context(root, gemini, errors)

    if errors:
        print("\n".join(errors))
        print(f"{len(errors)} problem(s)")
        return 1
    print(f"ok: {len(MANIFESTS)} manifests, {len(skills)} skills, {len(agents)} agents")
    return 0


if __name__ == "__main__":
    sys.exit(main(sys.argv[1] if len(sys.argv) > 1 else "."))
